﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PeriodicTable
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>



    public partial class MainWindow : Window
    {
        ElementDict d = new ElementDict();

        public MainWindow()
        {
            InitializeComponent();
            
        }

        //Upon click, the button should display information about the element
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string atomicNum = ((Button)sender).Tag.ToString();
            ElementData dat = d.dict[atomicNum];
            string elementName = dat.name;
            ElName.Text = elementName;
            ANum.Text = "Atomic Number: " + atomicNum;
            //((Button)sender).Background = Brushes.Aqua;
        }
    }

    //Dictionary containing the element data
    public class ElementDict
    {
        public Dictionary<string, ElementData> dict;

        public ElementDict()
        {
            dict = new Dictionary<string, ElementData>();
            dict.Add("1", new ElementData("Hydrogen"));
            dict.Add("2", new ElementData("Helium"));

            dict.Add("3", new ElementData("Lithium"));
            dict.Add("4", new ElementData("Beryllium"));
            dict.Add("5", new ElementData("Boron"));
            dict.Add("6", new ElementData("Carbon"));
            dict.Add("7", new ElementData("Nitrogen"));
            dict.Add("8", new ElementData("Oxygen"));
            dict.Add("9", new ElementData("Fluorine"));
            dict.Add("10", new ElementData("Neon"));

            dict.Add("11", new ElementData("Sodium"));
            dict.Add("12", new ElementData("Magnesium"));
            dict.Add("13", new ElementData("Aluminium"));
            dict.Add("14", new ElementData("Silicon"));
            dict.Add("15", new ElementData("Phosphorus"));
            dict.Add("16", new ElementData("Sulfur"));
            dict.Add("17", new ElementData("Chlorine"));
            dict.Add("18", new ElementData("Argon"));

            dict.Add("19", new ElementData("Potassium"));
            dict.Add("20", new ElementData("Calcium"));
            dict.Add("21", new ElementData("Scandium"));
            dict.Add("22", new ElementData("Titanium"));
            dict.Add("23", new ElementData("Vanadium"));
            dict.Add("24", new ElementData("Chromium"));
            dict.Add("25", new ElementData("Manganese"));
            dict.Add("26", new ElementData("Iron"));
            dict.Add("27", new ElementData("Cobalt"));
            dict.Add("28", new ElementData("Nickel"));
            dict.Add("29", new ElementData("Copper"));
            dict.Add("30", new ElementData("Zinc"));
            dict.Add("31", new ElementData("Gallium"));
            dict.Add("32", new ElementData("Germanium"));
            dict.Add("33", new ElementData("Arsenic"));
            dict.Add("34", new ElementData("Selenium"));
            dict.Add("35", new ElementData("Bromine"));
            dict.Add("36", new ElementData("Krypton"));

            dict.Add("37", new ElementData("Rubidium"));
            dict.Add("38", new ElementData("Strontium"));
            dict.Add("39", new ElementData("Yttrium"));
            dict.Add("40", new ElementData("Zirconium"));
            dict.Add("41", new ElementData("Niobium"));
            dict.Add("42", new ElementData("Molybdenum"));
            dict.Add("43", new ElementData("Technetium"));
            dict.Add("44", new ElementData("Ruthenium"));
            dict.Add("45", new ElementData("Rhodium"));
            dict.Add("46", new ElementData("Palladium"));
            dict.Add("47", new ElementData("Silver"));
            dict.Add("48", new ElementData("Cadmium"));
            dict.Add("49", new ElementData("Indium"));
            dict.Add("50", new ElementData("Tin"));
            dict.Add("51", new ElementData("Antimony"));
            dict.Add("52", new ElementData("Tellurium"));
            dict.Add("53", new ElementData("Iodine"));
            dict.Add("54", new ElementData("Xenon"));

            dict.Add("55", new ElementData("Caesium"));
            dict.Add("56", new ElementData("Barium"));
            dict.Add("57", new ElementData("Lanthanum"));

            dict.Add("58", new ElementData("Cerium"));
            dict.Add("59", new ElementData("Praseodymium"));
            dict.Add("60", new ElementData("Neodymium"));
            dict.Add("61", new ElementData("Promethium"));
            dict.Add("62", new ElementData("Samarium"));
            dict.Add("63", new ElementData("Europium"));
            dict.Add("64", new ElementData("Gadolinium"));
            dict.Add("65", new ElementData("Terbium"));
            dict.Add("66", new ElementData("Dysprosium"));
            dict.Add("67", new ElementData("Holmium"));
            dict.Add("68", new ElementData("Erbium"));
            dict.Add("69", new ElementData("Thulium"));
            dict.Add("70", new ElementData("Ytterbium"));
            dict.Add("71", new ElementData("Lutetium"));

            dict.Add("72", new ElementData("Hafnium"));
            dict.Add("73", new ElementData("Tantalum"));
            dict.Add("74", new ElementData("Tungsten"));
            dict.Add("75", new ElementData("Rhenium"));
            dict.Add("76", new ElementData("Osmium"));
            dict.Add("77", new ElementData("Iridium"));
            dict.Add("78", new ElementData("Platinum"));
            dict.Add("79", new ElementData("Gold"));
            dict.Add("80", new ElementData("Mercury"));
            dict.Add("81", new ElementData("Thallium"));
            dict.Add("82", new ElementData("Lead"));
            dict.Add("83", new ElementData("Bismuth"));
            dict.Add("84", new ElementData("Polonium"));
            dict.Add("85", new ElementData("Astatine"));
            dict.Add("86", new ElementData("Radon"));

            dict.Add("87", new ElementData("Francium"));
            dict.Add("88", new ElementData("Radium"));
            dict.Add("89", new ElementData("Actinium"));

            dict.Add("90", new ElementData("Thorium"));
            dict.Add("91", new ElementData("Protactinium"));
            dict.Add("92", new ElementData("Uranium"));
            dict.Add("93", new ElementData("Neptunium"));
            dict.Add("94", new ElementData("Plutonium"));
            dict.Add("95", new ElementData("Americium"));
            dict.Add("96", new ElementData("Curium"));
            dict.Add("97", new ElementData("Berkelium"));
            dict.Add("98", new ElementData("Californium"));
            dict.Add("99", new ElementData("Einsteinium"));
            dict.Add("100", new ElementData("Fermium"));
            dict.Add("101", new ElementData("Mendelevium"));
            dict.Add("102", new ElementData("Nobelium"));
            dict.Add("103", new ElementData("Lawrencium"));

            dict.Add("104", new ElementData("Rutherfordium"));
            dict.Add("105", new ElementData("Dubnium"));
            dict.Add("106", new ElementData("Seaborgium"));
            dict.Add("107", new ElementData("Bohrium"));
            dict.Add("108", new ElementData("Hassium"));
            dict.Add("109", new ElementData("Meitnerium"));
            dict.Add("110", new ElementData("Darmstadtium"));
            dict.Add("111", new ElementData("Roentgenium"));
            dict.Add("112", new ElementData("Copernicium"));
            dict.Add("113", new ElementData("Nihonium"));
            dict.Add("114", new ElementData("Flerovium"));
            dict.Add("115", new ElementData("Moscovium"));
            dict.Add("116", new ElementData("Livermorium"));
            dict.Add("117", new ElementData("Tennessine"));
            dict.Add("118", new ElementData("Oganesson"));
        }
    }

    //This is an object containing the element data for a single element
    public class ElementData
    {
        public ElementData(string n)
        {
            //atomicNum = aNum;
            name = n;
        }

        //public int atomicNum { get; set; }
        public string name { get; set; }
    }
}
